<?php

namespace Pterodactyl\Exceptions;

class AccountNotFoundException extends \Exception
{
}
